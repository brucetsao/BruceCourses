Installation procedure:
	After install Blynk library, Blynk.ino should be able to run.
	The library is identical with the Blynk 3.1, we only need Blynk sub directory..
	
This sample verified with the Blynk 3.1 and iphone. checked with Analog A0, Virtual V0
