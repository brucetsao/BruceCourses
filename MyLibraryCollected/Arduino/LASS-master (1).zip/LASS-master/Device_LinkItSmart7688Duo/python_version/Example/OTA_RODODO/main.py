from time import sleep
print 'hello world2'
while 1:
	print 'This is Linkit-7688'
	sleep(1)
