#完成一台IASS感測器有三大步驟：

##A)準備材料及組裝：
選擇您需要的感測位置

1.[辦公室專用感測裝置DIY] (https://chtseng.wordpress.com/2016/03/31/diy-%E8%BE%A6%E5%85%AC%E5%AE%A4%E7%9A%84%E6%84%9F%E6%B8%AC%E8%A3%9D%E7%BD%AE/)

2.[機房專用感測器DIY] (https://chtseng.wordpress.com/2016/03/31/%E6%A9%9F%E6%88%BF%E5%B0%88%E7%94%A8%E6%84%9F%E6%B8%AC%E5%99%A8diy-2/)

3.[居家安全專用感測器DIY] (https://chtseng.wordpress.com/2016/03/31/%E5%B1%85%E5%AE%B6%E5%AE%89%E5%85%A8%E5%B0%88%E7%94%A8%E6%84%9F%E6%B8%AC%E5%99%A8diy/)
	
##B)[申請及設定Thinkgspeak帳號] (https://chtseng.wordpress.com/2016/03/31/%E7%94%B3%E8%AB%8B%E5%8F%8A%E8%A8%AD%E5%AE%9Athinkgspeak%E5%B8%B3%E8%99%9F/)

##C)[程式燒錄及報表設定] (https://chtseng.wordpress.com/2016/03/31/%E7%A8%8B%E5%BC%8F%E7%87%92%E9%8C%84%E5%8F%8A%E5%A0%B1%E8%A1%A8%E8%A8%AD%E5%AE%9A/)
